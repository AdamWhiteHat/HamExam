/*
 * Created by SharpDevelop.
 * User: BurningBunny
 * Date: 1/14/2013
 * Time: 2:51 PM
 * 
 * 
 */
using System;
using System.IO;
using System.Drawing;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Threading;

namespace HamExam
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			InitializeComponent();
		}
		
		public static void MyExceptionHandler(object sender, ThreadExceptionEventArgs e) {
			MessageBox.Show("Error: " + e.Exception.Message,"HamExam",MessageBoxButtons.OK,MessageBoxIcon.Error);
		}
		
		Random rand = new Random();
		string[] Questions;
		int NumQuestions = 0;
		int QuestionsAsked = 0;
		int QuestionsCorrect = 0;
		int QuestionsIncorrect = 0;
		bool Answered = false;
		int LastQNum = 0;
		char cAnswer = ' ';
		
		
		void MainFormLoad(object sender, EventArgs e)
		{
			ResetTest();
		}
		
		void BtnNextQuestionClick(object sender, EventArgs e)
		{
			LoadNextQuestion();
		}
		
		void ResetTest()
		{
			rand.Next();
			LoadQuestionPool("TechnicianClass.QuestionPool");
			NumQuestions = Questions.Length;
			
			LastQNum = 0;
			QuestionsAsked = 0;
			QuestionsCorrect = 0;
			QuestionsIncorrect = 0;
			Answered = false;
			cAnswer = ' ';
			LoadNextQuestion();
		}
		
		void LoadNextQuestion()
		{
			int qNum = rand.Next(NumQuestions); // Select a random question from 0 to NumQuestions
			while(qNum == LastQNum) {			// Make sure we didnt select the same question
				qNum = rand.Next(NumQuestions);
			}
			LastQNum = qNum;					// Set last question
			
			// Reset checked state
			radioAnswerA.Checked = false;
			radioAnswerB.Checked = false;
			radioAnswerC.Checked = false;
			radioAnswerD.Checked = false;
			// Reset control colors
			radioAnswerA.BackColor = Color.FromKnownColor(KnownColor.Control);
			radioAnswerB.BackColor = Color.FromKnownColor(KnownColor.Control);
			radioAnswerC.BackColor = Color.FromKnownColor(KnownColor.Control);
			radioAnswerD.BackColor = Color.FromKnownColor(KnownColor.Control);
			
			QuestionsAsked++; // Increment questions asked
			Answered = false; // Allow user to answer
			
			// Update score
			labelQuestionsCorrect.Text = QuestionsCorrect.ToString();
			labelQuestionsTotal.Text = QuestionsAsked.ToString();
			
			
			string[] CurrentQuestion = Questions[qNum].Split('\n');
			
			labelQuestion.Text= CurrentQuestion[2];
			radioAnswerA.Text = CurrentQuestion[3];
			radioAnswerB.Text = CurrentQuestion[4];
			radioAnswerC.Text = CurrentQuestion[5];
			if(CurrentQuestion.Length>7) {
				radioAnswerD.Visible = true;
				radioAnswerD.Text = CurrentQuestion[6];
			} else {
				radioAnswerD.Visible = false;
			}
			
			// Figure out the correct answer
			char[] delimiterChars = { '(', ')' };
			
			string[] QuestionInfo = CurrentQuestion[1].Split(delimiterChars);
			labelQID.Text = QuestionInfo[0];
			cAnswer = QuestionInfo[1][0];

			// Debug output..
			labelDebug.Text = "Question #" + qNum.ToString() + " of " + NumQuestions.ToString();
			//labelDebug.Text += ": Elements: " + CurrentQuestion.Length.ToString();
			//labelDebug.Text += " & Answer: " + QuestionInfo[1];
		}
		

		void LoadQuestionPool(string FileName)
		{
			string FileData;
			using (StreamReader sr = new StreamReader(FileName)) {
				FileData = sr.ReadToEnd();
			}
			Questions = FileData.Split('~');
		}
		
		
		
		
		void RadioAnswerACheckedChanged(object sender, EventArgs e)
		{
			if(!Answered)
			{
				Answered = true;
				if(cAnswer=='A') {
					radioAnswerA.BackColor = Color.MintCream;
					QuestionsCorrect+=1;
					labelQuestionsCorrect.Text = QuestionsCorrect.ToString();
				} else {
					radioAnswerA.BackColor = Color.MistyRose;
					QuestionsIncorrect++;
					if(cAnswer=='B') {
						radioAnswerB.BackColor = Color.MintCream;
					} else if(cAnswer=='C') {
						radioAnswerB.BackColor = Color.MintCream;
					} else if(cAnswer=='D') {
						radioAnswerD.BackColor = Color.MintCream;
					}
				}
			}
		}
		void RadioAnswerBCheckedChanged(object sender, EventArgs e)
		{
			if(!Answered)
			{
				Answered = true;
				if(cAnswer=='B') {
					radioAnswerB.BackColor = Color.MintCream;
					QuestionsCorrect+=1;
					labelQuestionsCorrect.Text = QuestionsCorrect.ToString();
				} else {
					radioAnswerB.BackColor = Color.MistyRose;
					QuestionsIncorrect++;
					if(cAnswer=='A') {
						radioAnswerA.BackColor = Color.MintCream;
					} else if(cAnswer=='C') {
						radioAnswerC.BackColor = Color.MintCream;
					} else if(cAnswer=='D') {
						radioAnswerD.BackColor = Color.MintCream;
					}
				}
			}
		}
		void RadioAnswerCCheckedChanged(object sender, EventArgs e)
		{
			if(!Answered)
			{
				Answered = true;
				if(cAnswer=='C') {
					radioAnswerC.BackColor = Color.MintCream;
					QuestionsCorrect+=1;
					labelQuestionsCorrect.Text = QuestionsCorrect.ToString();
				} else {
					radioAnswerC.BackColor = Color.MistyRose;
					QuestionsIncorrect++;
					if(cAnswer=='A') {
						radioAnswerA.BackColor = Color.MintCream;
					} else if(cAnswer=='B') {
						radioAnswerB.BackColor = Color.MintCream;
					} else if(cAnswer=='D') {
						radioAnswerD.BackColor = Color.MintCream;
					}
				}
			}
		}
		void RadioAnswerDCheckedChanged(object sender, EventArgs e)
		{
			if(!Answered)
			{
				Answered = true;
				if(cAnswer=='D') {
					radioAnswerD.BackColor = Color.MintCream;
					QuestionsCorrect+=1;
					labelQuestionsCorrect.Text = QuestionsCorrect.ToString();
				} else {
					radioAnswerD.BackColor = Color.MistyRose;
					QuestionsIncorrect++;
					if(cAnswer=='A') {
						radioAnswerA.BackColor = Color.MintCream;
					} else if(cAnswer=='B') {
						radioAnswerB.BackColor = Color.MintCream;
					} else if(cAnswer=='C') {
						radioAnswerC.BackColor = Color.MintCream;
					}
				}
			}
		}
	}
}
